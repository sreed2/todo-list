import React from "react";
import { ITask } from "../Interfaces";

interface Props {
    task: ITask;
    deleteTask(taskNameToDelete: string): void;
    completeTask(taskNameToComplete: string): void;
}

const TodoTask = ({task, deleteTask, completeTask}: Props) => {

    return (
        <div className="task">
            <div className="content">
                {task.complete ? (
                    <span style={{ textDecoration: 'line-through'}}>{task.taskName}</span>
                ) : (
                    <span>{task.taskName}</span>
                )}
                
                <span>{task.deadline} days ago</span>
                {task.deadline >= 5 ? (
                    <span style={{ backgroundColor: 'red'}}>Old</span>
                ) : (
                    <span style={{ backgroundColor: 'green'}}>New</span>
                )}
            </div>
            <button onClick={() => {
                completeTask(task.taskName)
            }}>
                Done
            </button>
            <button onClick={() => {
                deleteTask(task.taskName)
            }}>
                Delete
            </button>
        </div>
    );
};

export default TodoTask;