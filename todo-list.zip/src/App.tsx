import React, {FC, useState, ChangeEvent} from 'react';
import './App.css';
import { ITask } from './Interfaces';
import TodoTask from './Components/TodoTasks';

const App: FC = () => {
  const [task, setTask] = useState<string>("");
  const [deadline, setDeadline] = useState<number>(0);
  const [todoList, setTodoList] = useState<ITask[]>(
    [
      {taskName: "Grade Paper", deadline: 3},
      {taskName: "Pop Quiz", deadline: 5},
    ]
  );

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    if(event.target.name === "task"){
      setTask(event.target.value);
    }
    else {
      setDeadline(Number(event.target.value))
    }
  }

  const addTask = () => {
    const newTask = {taskName: task, deadline: deadline};
    setTodoList([...todoList, newTask]);
    setTask("");
    setDeadline(0);
  }

  const deleteTask = (taskNameToDelete: string) => {
    setTodoList(todoList.filter((task) => {
      return task.taskName !== taskNameToDelete;
    }));
  }

  const completeTask = (taskNameToComplete: string) => {
    setTodoList(todo => {
      // loop over the todos list and find the provided name.
      return todo.map(item => {
          return item.taskName === taskNameToComplete ? {...item, complete: true} : item
      })
    });
  }

  return (
    <div className="App">
      <div className="header">
        <div className='inputGroup'>
          <input 
            type="text" 
            placeholder='Task...' 
            name="task" 
            value={task}
            onChange={handleChange} 
          />
          <input 
            type="number" 
            placeholder='Deadline...' 
            name="deadline"
            value={deadline}
            onChange={handleChange} 
          />
        </div>
        <button onClick={addTask}>Add Task</button>
      </div>
      <div className="todoList"> 
        {todoList.map((task: ITask, key: number) => {
          return <TodoTask 
            key={key} 
            task={task} 
            deleteTask={deleteTask} 
            completeTask={completeTask}  
          />; 
        })}
      </div>
    </div>
  );
};

export default App;
