export interface ITask {
    taskName: string;
    deadline: number;
    complete?: boolean;
}